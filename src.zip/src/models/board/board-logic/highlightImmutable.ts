import { Board } from "../Board";
import { Cell } from "../Cell";
import { highlightCells } from "./highlight";

/** Повертає нову копію дошки з підсвіткою */
export function getBoardWithHighlights(board: Board, selectedCell: Cell | null): Board {
  const copy = board.getCopyBoard();
  highlightCells(copy, selectedCell);
  return copy;
}
