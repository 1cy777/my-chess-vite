import { Colors } from '@/models/Colors';

export class Player {
  color: Colors;


  constructor(color: Colors) {
    this.color = color;
  }
}
